//Automatically generated file - do not edit
#define DATE_STR "11.11.2010"
#define TIME_STR "12:12:37"
#define SUB_VERS 1-bryan
#define SVN_VERS "trunk-r262"
